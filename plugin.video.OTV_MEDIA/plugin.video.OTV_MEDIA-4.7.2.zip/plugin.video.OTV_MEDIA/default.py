#-*- coding: utf-8 -*-

import urllib2,xbmc, urllib, sys, xbmcplugin ,xbmcgui, xbmcaddon, xbmc, os, json, shutil, time, zipfile, re, stat, xbmcvfs, base64
         
from resources.lib.statistic import cStatistic
from resources.lib.gui.hoster import cHosterGui
from resources.lib.gui.guiElement import cGuiElement
from resources.lib.home import cHome
from resources.lib.gui.gui import cGui
from resources.lib.handler.pluginHandler import cPluginHandler
from resources.lib.handler.inputParameterHandler import cInputParameterHandler
from resources.lib.handler.outputParameterHandler import cOutputParameterHandler
from resources.lib.config import cConfig
from resources.lib.db import cDb
from resources.lib.cconfig import ccConfig
import six
from resources.lib.comaddon import progress, VSlog, addon, window, xbmc
from resources.lib.handler.rechercheHandler import cRechercheHandler
import  xbmc
import re,threading
import os
import traceback
import urllib, urllib2, re, sys, os

import base64
#import ngx
from urlparse import parse_qs
import hashlib
from urllib import unquote_plus
#from f4mProxy import F4mProxy 

import urlparse,sys,re,os
import cookielib,base64
iconimage=None
from resources.lib import comon
from os.path import join
from sys import path

from resources.lib import common
from resources.lib import logger

 
__settings__ = common.addon
__cwd__ = common.addonPath
 
path.append(join(__cwd__, "resources", "lib"))
path.append(join(__cwd__, "resources", "lib", "gui"))
path.append(join(__cwd__, "resources", "lib", "handler"))
path.append(join(__cwd__, "resources", "sites"))
#path.append(join(__cwd__, "sites"))
addons = addon()
class main:
 def __init__(self,argv=None):
    if sys.argv:
        argv = sys.argv
    self.parseUrl()
    cDb()._create_tables()
    
 

 
 def parseUrl(self):
        
            
        params = cInputParameterHandler()
        oInputParameterHandler = cInputParameterHandler()
        #print 'Debug 2'
        if (oInputParameterHandler.exist('function')):
            #print 'Debug 3'
            sFunction = oInputParameterHandler.getValue('function')
        else:
            #print 'Debug 4'
            cConfig().log('call load methode')
            sFunction = "load"

        #print 'Debug 5'   
        if (sFunction=='DoNothing'):
            return

        if (oInputParameterHandler.exist('site')):
            sSiteName = oInputParameterHandler.getValue('site')
            
            if params.exist('playMode'):
               from resources.lib.gui.ahoster import HosterGui
               url = False
               playMode = params.getValue('playMode')
               isHoster = params.getValue('isHoster')
               url = params.getValue('url')
               manual = params.exist('manual')
               if ccConfig().getSetting(
                       'hosterSelect') == 'Auto' and playMode != 'jd' and playMode != 'jd2' and playMode != 'pyload' and not manual:
                   HosterGui().streamAuto(playMode, sSiteName, sFunction)
               else:
                   HosterGui().stream(playMode, sSiteName, sFunction, url)
               return             
            
        if (not oInputParameterHandler.exist('site')):
            #mise a jour
            try:
                #from resources.lib.about import cAbout
                #cAbout().getUpdate()
                plugins = __import__('resources.lib.about', fromlist=['about']).cAbout()
                function = getattr(plugins, 'getUpdate')
                function()
            except:
                pass
            #charge home
            plugins = __import__('resources.lib.home', fromlist=['home']).cHome()
            function = getattr(plugins, 'load')
            function()
            return


        if (oInputParameterHandler.exist('site')):
            sSiteName = oInputParameterHandler.getValue('site')
            if (oInputParameterHandler.exist('title')):
                sTitle = oInputParameterHandler.getValue('title')
            else: sTitle = "none"

            VSlog('load site ' + sSiteName + ' and call function ' + sFunction)
            #cStatistic().callStartPlugin(sSiteName, sTitle)

            if (isHosterGui(sSiteName, sFunction) == True):
                return

            if (isGui(sSiteName, sFunction) == True):
                return

            if (isFav(sSiteName, sFunction) == True):
                return

            if (isLibrary(sSiteName, sFunction) == True):
                return

            if (isDl(sSiteName, sFunction) == True):
                return

            if (isHome(sSiteName, sFunction) == True):
                return

            if (isTrakt(sSiteName, sFunction) == True):
                return

            if sSiteName == 'globalSearch':
                searchGlobal()
                return

            if sSiteName == 'globalRun':
                __import__('resources.lib.runscript', fromlist=['runscript'])
                #function = getattr(plugins, sFunction)
                #function()
                return

            if sSiteName == 'globalSources':

                oGui = cGui()
                oPluginHandler = cPluginHandler()
                aPlugins = oPluginHandler.getAvailablePlugins(True)
                if (len(aPlugins) == 0):
                    addons = addon()
                    addons.openSettings()
                    xbmc.executebuiltin("Container.Refresh")
                else:
                    for aPlugin in aPlugins:

                        oOutputParameterHandler = cOutputParameterHandler()
                        oOutputParameterHandler.addParameter('siteUrl', 'http://orhan')
                        icon = 'sites/%s.png' % (aPlugin[1])
                        #icon = 'https://imgplaceholder.com/512x512/transparent/fff?text=%s&font-family=Roboto_Bold' % aPlugin[1]
                        oGui.addDir(aPlugin[1], 'load', aPlugin[0], icon, oOutputParameterHandler)

                oGui.setEndOfDirectory()
                return

            if sSiteName == 'globalParametre':
                addons = addon()
                addons.openSettings()
                return
            #if (isAboutGui(sSiteName, sFunction) == True):
                #return

            #charge sayfalar
            try:
            #exec "from resources.sayfalar import " + sSiteName + " as plugin"
            #exec "plugin."+ sFunction +"()"
                plugins = __import__('resources.sites.%s' % sSiteName, fromlist=[sSiteName])
                function = getattr(plugins, sFunction)
                function()
            except Exception as e:
                VSlog('could not load site: ' + sSiteName + ' error: ' + str(e))
                import traceback
                traceback.print_exc()
                return
                
               

 
            

       
        
def isHosterGui(sSiteName, sFunction):
    if (sSiteName == 'cHosterGui'):
        oHosterGui = cHosterGui()
        exec "oHosterGui."+ sFunction +"()"
        return True
    return False
    
def isGui(sSiteName, sFunction):
    if (sSiteName == 'cGui'):
        oGui = cGui()
        exec "oGui."+ sFunction +"()"
        return True
    return False
    
def isFav(sSiteName, sFunction):
    if (sSiteName == 'cFav'):
        from resources.lib.favourite import cFav
        oFav = cFav()
        exec "oFav."+ sFunction +"()"
        return True
    return False
    
def isLibrary(sSiteName, sFunction):
    if (sSiteName == 'cLibrary'):
        from resources.lib.library import cLibrary
        oLibrary = cLibrary()
        exec "oLibrary."+ sFunction +"()"
        return True
    return False

def isDl(sSiteName, sFunction):
    if (sSiteName == 'cDownload'):
        from resources.lib.download import cDownload
        oDownload = cDownload()
        exec "oDownload."+ sFunction +"()"
        return True
    return False

def isHome(sSiteName, sFunction):
    if (sSiteName == 'cHome'):
        oHome = cHome()
        exec "oHome."+ sFunction +"()"
        return True
    return False
def isTrakt(sSiteName, sFunction):
    if sSiteName == 'cTrakt':
        from resources.lib.trakt import cTrakt
        oTrakt = cTrakt()
        exec ("oTrakt." + sFunction + "()")
        return True
    return False

def searchGlobal():
    oGui = cGui()
    addons = addon()

    oInputParameterHandler = cInputParameterHandler()
    sSearchText = oInputParameterHandler.getValue('searchtext')
    sCat = oInputParameterHandler.getValue('sCat')

    oHandler = cRechercheHandler()
    oHandler.setText(sSearchText)
    oHandler.setCat(sCat)
    aPlugins = oHandler.getAvailablePlugins()
    if not aPlugins:
        return True

    total = len(aPlugins)
    progress_ = progress().VScreate()

    # kodi 17 vire la fenetre busy qui se pose au dessus de la barre de Progress
    try:
        xbmc.executebuiltin('Dialog.Close(busydialog)')
    except:
        pass

    oGui.addText('globalSearch', addons.VSlang(30081) % sSearchText, 'none.png')
    sSearchText = Quote(sSearchText)

    count = 0
    for plugin in aPlugins:
 
        progress_.VSupdate(progress_, total, plugin['name'], True)
        if progress_.iscanceled():
            progress_.close()
            break
 
        oGui.searchResults[:] = []  # vider le tableau de résultats pour les récupérer par source
        _pluginSearch(plugin, sSearchText)

        if len(oGui.searchResults) > 0: # Au moins un résultat
            count += 1

            # nom du site
            oGui.addText(plugin['identifier'], '%s. [COLOR olive]%s[/COLOR]' % (count, plugin['name']), 'sites/%s.png' % (plugin['identifier']))
            for result in oGui.searchResults:
                oGui.addFolder(result['guiElement'], result['params'])
 
    if not count:   # aucune source ne retourne de résultats
        oGui.addText('globalSearch') # "Aucune information"

    progress_.VSclose(progress_)

    oGui.setEndOfDirectory()
    return True


def _pluginSearch(plugin, sSearchText):

    # Appeler la source en mode Recherche globale
    window(10101).setProperty('search', 'true')
    
    try:
        plugins = __import__('resources.sites.%s' % plugin['identifier'], fromlist = [plugin['identifier']])
        function = getattr(plugins, plugin['search'][1])
        sUrl = plugin['search'][0] + str(sSearchText)
        
        function(sUrl)
        
        VSlog('Load Search: ' + str(plugin['identifier']))
    except:
        VSlog(plugin['identifier'] + ': search failed')

    window(10101).setProperty('search', 'false')

def get_params():
	param = []
	paramstring = sys.argv[2]
	if len(paramstring)>= 2:
		params = sys.argv[2]
		cleanedparams = params.replace('?', '')
		if (params[len(params)-1] == '/'):
			params = params[0:len(params)-2]
		pairsofparams = cleanedparams.split('&')
		param = {}
		for i in range(len(pairsofparams)):
			splitparams = {}
			splitparams = pairsofparams[i].split('=')
			if (len(splitparams)) == 2:
				param[splitparams[0]] = splitparams[1]
	return param

params = get_params()
url = None
name = None
mode = None
iconimage = None

try:
	url = urllib.unquote_plus(params["url"])
except:
	pass
try:
	name = urllib.unquote_plus(params["name"])
except:
	pass
try:
	mode = int(params["mode"])
except:
	pass
try:
	iconimage = urllib.unquote_plus(params["iconimage"])
except:
	pass

print "Mode: " + str(mode)
print "URL: " + str(url)
print "Name: " + str(name)
print "iconimage: " + str(iconimage)
    


if mode == None or url == None or len(url) < 1:
	sys.exit(main())

elif mode == 1:
	from resources.sites.adult import *
        search()

elif mode == 2:
	xbmc.log("mode==2, starturl=%s" % url, xbmc.LOGERROR)
	from resources.sites.adult import *
        start(url)

elif mode == 3:
	from resources.sites.adult import *
        media_list(url)
elif mode == 4:
	from resources.sites.adult import *
        resolve_url(url)
elif mode == 8:
	from resources.sites.adult import *
        redtube_sorting(url)
elif mode == 9:
	from resources.sites.adult import *
        redtube_categories(url)
elif mode == 12:
	from resources.sites.adult import *
        lubtetube_pornstars(url)
elif mode == 13:
	from resources.sites.adult import *
        flv_channels_list(url)
elif mode == 16:
	from resources.sites.adult import *
        vikiporn_categories(url)
elif mode == 17:
	from resources.sites.adult import *
        xhamster_categories(url)
elif mode == 18:
	from resources.sites.adult import *
        fantasti_categories(url)
elif mode == 23:
	from resources.sites.adult import *
        zbporn_categories(url)
elif mode == 24:
	from resources.sites.adult import *
        xhamster_content(url)
elif mode == 27:
	from resources.sites.adult import *
        xvideos_categories(url)
elif mode == 28:
	from resources.sites.adult import *
        youjizz_categories(url)
elif mode == 29:
	from resources.sites.adult import *
        hentaigasm_categories(url)
elif mode == 30:
	from resources.sites.adult import *
        ashemaletube_categories(url)
elif mode == 32:
	from resources.sites.adult import *
        xvideos_pornstars(url)
elif mode == 33:
	from resources.sites.adult import *
        heavyr_categories(url)
elif mode == 39:
	from resources.sites.adult import *
        pornxs_categories(url)
elif mode == 41:
	from resources.sites.adult import *
        gotporn_content(url)
elif mode == 42:
	from resources.sites.adult import *
        xhamster_rankigs(url)
elif mode == 44:
	from resources.sites.adult import *
        motherless_sorting(url)
elif mode == 45:
	from resources.sites.adult import *
        emplix_categories(url)
elif mode == 46:
	from resources.sites.adult import *
        emplix_sorting(url)
elif mode == 48:
	from resources.sites.adult import *
        fantasti_collections(url)
elif mode == 49:
	from resources.sites.adult import *
        fatasti_sorting(url)
elif mode == 52:
	from resources.sites.adult import *
        yespornplease_categories(url)
elif mode == 54:
	from resources.sites.adult import *
        uflash_categories(url)
elif mode == 55:
	from resources.sites.adult import *
        ashemaletube_pornstars(url)
elif mode == 60:
	from resources.sites.adult import *
        motherless_galeries_cat(url)
elif mode == 61:
	from resources.sites.adult import *
        motherless_being_watched_now(url)
elif mode == 62:
	from resources.sites.adult import *
	motherless_groups_cat(url)
elif mode == 64:
	from resources.sites.adult import *
	javbangers_categories(url)
elif mode == 68:
	from resources.sites.adult import *
	luxuretv_categories(url)
elif mode == 71:
	 from resources.sites.adult import *
	 xvideos_sorting(url)

elif mode == 100:
        from resources.sites.turkvod_org  import *
        
        ok = Liste(name, url)
elif mode == 200:
        from resources.sites.turkvod_org  import *
        sys.exit(VideoListe(name, url))
elif mode == 300:
        from resources.sites.turkvod_org  import *
        sys.exit(Oynat(name, url))
elif mode == 400:
        from resources.sites.turkvod_org  import *
        ok = Aramasonucu(name, url)
elif mode == 70:
	Header = 'User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36'
        url = url+ '|' + Header 
        item = xbmcgui.ListItem(name, path = url)
	item.setMimeType('video/mp4')
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
xbmcplugin.endOfDirectory(int(sys.argv[1]))